#!/usr/bin/env python
# coding: utf-8

# In[2]:


from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, SGDRegressor
from sklearn.metrics import mean_squared_error

import pandas as pd 
import os
import numpy as np


# In[21]:


"""
def sampleSGDRegressor():
    
    #梯度下降的優化方法
    #:return:
    
    # 1）獲取資料
    boston = load_boston()
    print("特徵數量：\n", boston.data.shape)  # 幾個特徵對應幾個權重係數

    # 2）劃分資料集
    x_train, x_test, y_train, y_test = train_test_split(boston.data, boston.target, random_state=22)

    # 3）標準化
    transfer = StandardScaler()
    x_train = transfer.fit_transform(x_train)
    x_test = transfer.transform(x_test)

    # 4）預估器
    estimator = SGDRegressor(learning_rate="constant", eta0=0.001, max_iter=10000)
    estimator.fit(x_train, y_train)

    # 5）得出模型
    print("梯度下降權重係數為：\n", estimator.coef_)
    print("梯度下降偏置為：\n", estimator.intercept_)

    # 6）模型評估
    y_predict = estimator.predict(x_test)
    print("預測房價：\n", y_predict)
    error = mean_squared_error(y_test, y_predict)
    print("梯度下降-均分誤差為：\n", error)

    return None
"""
def ourSGDRegressor(traindata,testdata):
    """
    梯度下降的優化方法
    :return:
    """
    # 1）獲取資料
    load_data = traindata
       
    # 探索性分析 Exploratory data analysis，了解資料集內容
    # feature 值
    df_tmp = load_data.drop(['SeqNo'], axis=1)
    df_feature = df_tmp.drop(['O'], axis=1)
    print("特徵數量：") 
    print(df_feature.shape)  # 幾個特徵對應幾個權重係數        
    # 目標值
    df_target = load_data['O']      
    
    # 2）劃分資料集
    # 將資料切分為 training data 和 testing data，其中 random_state 若設為 0 或不設則即便實例不同但因種子相同產生同樣隨機編號，若設為 1 則每次隨機產生不同編號
    # test_size 為切分 training data 和 testing data 的比例
    df_X = df_feature
    df_y = df_target
    x_train, x_test, y_train, y_test = train_test_split(df_X, df_y, train_size = 0.75, test_size = 0.25, random_state = 1234)

    # 3）標準化
    transfer = StandardScaler()
    
    #fit方法计算用于以后缩放的mean和std,默认参数情况下，mean是平均数
    #std是标准差，就是所有数减去其平均值的平方和，所得结果除以该组数之个数（或个数减一，即变异数），再把所得值开根号，所得之数就是这组数据的标准差
    x_scaler = transfer.fit(x_train)
    y_scaler = transfer.fit(y_train.values.reshape(-1,1))
    
    standardized_x_train = x_scaler.transform(x_train)
    standardized_y_train = y_scaler.transform(y_train.values.reshape(-1,1)).ravel()
    standardized_x_test = x_scaler.transform(x_test)
    standardized_y_test = y_scaler.transform(y_test.values.reshape(-1,1)).ravel()

    # 4）預估器
    estimator = SGDRegressor(loss='squared_loss', penalty='none', max_iter=100)    
    estimator.fit(X=standardized_x_train,y=standardized_y_train)

    # 5）得出模型
    #predict：进行数据预测
    #scaler.var_是方差，np.sqrt(y_scaler.var_)就是标准差,y_scaler.scale_也是标准差，是一样的
    #实际输出结果就是 (模拟的输出结果 * 标准差) + 平均数 和标准化过程刚好相反 
    predict_train = (estimator.predict(standardized_x_train) * y_scaler.scale_) + y_scaler.mean_
    predict_test = (estimator.predict(standardized_x_test) * np.sqrt(y_scaler.var_)) + y_scaler.mean_
    
    print("Model train predict :")
    print(predict_train)
    print("Model test predict :")
    print(predict_test)    
    
    print("梯度下降權重係數為：")
    print(estimator.coef_)
    print("梯度下降偏置為：")
    print(estimator.intercept_)
        
    # 6）模型評估
    error = mean_squared_error(y_test, predict_test)
    print("梯度下降-均分誤差為：")
    print(error)
    
    #测试我们自己的数据
    # 1）獲取資料
    load_data = df_test    
    df_tmp = load_data.drop(['SeqNo'], axis=1)
    
    X_infer = df_tmp 
    standardized_X_infer = x_scaler.transform(X_infer)
    pred_infer = (estimator.predict(standardized_X_infer) * np.sqrt(y_scaler.var_)) + y_scaler.mean_
    print("最終預測結果 : ")
    print(pred_infer)
    
    return None

if __name__ == '__main__':        
    RUNfilePath = os.path.join("../../","Data")
    DatafileName = "train20210817v2.csv"
    openfilePath = os.path.join(RUNfilePath,DatafileName)
    df_train = pd.read_csv(openfilePath) 
    
    RUNfilePath = os.path.join("../../","Data")
    DatafileName = "2021test0831.csv"
    openfilePath = os.path.join(RUNfilePath,DatafileName)
    df_test = pd.read_csv(openfilePath) 
   
    print("程式評估中......")
    ourSGDRegressor(traindata=df_train,testdata=df_test)


# In[ ]:




