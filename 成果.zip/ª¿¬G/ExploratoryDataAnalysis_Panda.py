#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system(u'pip3 install pandas')


# In[2]:


import pandas as pd 
import os

#filePath = os.getcwd()
RUNfilePath = os.path.join("../","Data")
fileName = "train20210817v2.csv"
openfilePath = os.path.join(RUNfilePath,fileName)
df = pd.read_csv(openfilePath) 

#print(df)
print("這是訓練資料(未整理) : ")
df

SavefilePath = os.path.join(RUNfilePath,"train20210817v2.html")
df.to_html(SavefilePath)


# In[3]:


import pandas as pd 
import os
import numpy as np

import StringIO

#filePath = os.getcwd()
RUNfilePath = os.path.join("../","Data")
fileName = "train20210817v2.csv"
openfilePath = os.path.join(RUNfilePath,fileName)
df = pd.read_csv(openfilePath) 

SavefilePath =""
SaveDataFrame = pd.DataFrame()


# In[7]:


print("【檔案的基本訊息】")
#print(df.describe())
df_info = df.info()
print(df_info)
print("\n")

"""
import StringIO
output = StringIO.StringIO()
#Write df.info to a string buffer
df.info(buf=output)
#put the info back to a dataframe so you can use df.to_html()
df_info =  pd.DataFrame(columns=['DF INFO'], data=output.getvalue().split('\n'))
df_info.to_html()
"""

output = StringIO.StringIO()
df.info(buf=output,verbose=True)
SaveDataFrame =  pd.DataFrame(columns=['DF INFO'], data=output.getvalue().split('\n'))
SavefilePath = os.path.join(RUNfilePath,"Datainfo.html")
SaveDataFrame.to_html(SavefilePath)

SavefilePath = os.path.join(RUNfilePath,"Datainfo.csv")
SaveDataFrame.to_csv(SavefilePath)


# In[8]:


# 探索性分析 Exploratory data analysis，了解資料集內容
# 先印出 key 值，列出有哪些值
print("DATA的key值 : ")
df_key = df.keys()
print(df_key)
print("\n")

df_key_series = pd.Series(df_key)
SaveDataFrame = pd.DataFrame(df_key_series, columns=['O'])

SavefilePath = os.path.join(RUNfilePath,"Datakey.html")
SaveDataFrame.to_html(SavefilePath)

SavefilePath = os.path.join(RUNfilePath,"Datakey.csv")
SaveDataFrame.to_csv(SavefilePath)


# In[11]:


# 探索性分析 Exploratory data analysis，了解資料集內容
# 印出 feature 值
print("feature的值 : ")
df_tmp = df.drop(['SeqNo'], axis=1)
df_feature = df_tmp.drop(['O'], axis=1)
print(df_feature)
print("\n")

SavefilePath = os.path.join(RUNfilePath,"Datafeature.html")
df_feature.to_html(SavefilePath)

SavefilePath = os.path.join(RUNfilePath,"Datafeature.csv")
df_feature.to_csv(SavefilePath)


# In[12]:


# 探索性分析 Exploratory data analysis，了解資料集內容
# 印出 feature 值狀況
print("feature的值 : ")
df_tmp = df.drop(['SeqNo'], axis=1)
df_feature = df_tmp.drop(['O'], axis=1)
df_feature_describe = df_feature.describe()
print(df_feature_describe)
print("\n")

SavefilePath = os.path.join(RUNfilePath,"Datafeaturedescribe.html")
df_feature_describe.to_html(SavefilePath)

SavefilePath = os.path.join(RUNfilePath,"Datafeaturedescribe.csv")
df_feature_describe.to_csv(SavefilePath)


# In[9]:


# 探索性分析 Exploratory data analysis，了解資料集內容
# 印出目標值
print("目標值的值 : ")
df_target = df['O']
print(df_target)
print("\n")

df_target_series = pd.Series(df_target)
SaveDataFrame = pd.DataFrame(df_target_series)
SavefilePath = os.path.join(RUNfilePath,"Datatarget.html")
SaveDataFrame.to_html(SavefilePath)

SavefilePath = os.path.join(RUNfilePath,"Datatarget.csv")
SaveDataFrame.to_csv(SavefilePath)


# In[10]:


# 探索性分析 Exploratory data analysis，了解資料集內容
# 類別種類
print("目標值的類別種類(Label) : ")
df_label = np.unique(df.O)
print(df_label)

SaveDataFrame = pd.DataFrame(df_label)
SavefilePath = os.path.join(RUNfilePath,"Datalabel.html")
SaveDataFrame.to_html(SavefilePath)

SavefilePath = os.path.join(RUNfilePath,"Datalabel.csv")
SaveDataFrame.to_csv(SavefilePath)


# In[ ]:




